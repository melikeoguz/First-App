package com.android.website;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends AppCompatActivity {

    WebView site;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        site=findViewById(R.id.web);
        site.setWebViewClient(new WebViewClient());
        site.getSettings().getJavaScriptEnabled();
        site.getSettings().getBuiltInZoomControls();
        site.loadUrl("file:///android_asset/login.html"); //Assets olarak yazilmaz zaten assetsi anlar

    }
}
